document.addEventListener('DOMContentLoaded', () => {
    const agentsContainer = document.getElementById('agents-container');
    const mapsContainer = document.getElementById('maps-container');

    fetch('assets/data/agents.json')
        .then(response => response.json())
        .then(data => {
            if (agentsContainer) {
                data.agents.forEach(agent => {
                    const agentDiv = document.createElement('div');
                    agentDiv.className = 'agent';
                    agentDiv.innerHTML = `
                        <h3>${agent.name}</h3>
                        <img src="assets/images/${agent.image}" alt="${agent.name}">
                        <p>${agent.description}</p>
                        <h4>Abilities:</h4>
                        <ul>
                            ${agent.abilities.map(ability => `<li>${ability}</li>`).join('')}
                        </ul>
                    `;
                    agentsContainer.appendChild(agentDiv);
                });
            }
        });

    fetch('assets/data/maps.json')
        .then(response => response.json())
        .then(data => {
            if (mapsContainer) {
                data.maps.forEach(map => {
                    const mapDiv = document.createElement('div');
                    mapDiv.className = 'map';
                    mapDiv.innerHTML = `
                        <h3>${map.name}</h3>
                        <img src="assets/images/${map.image}" alt="${map.name}">
                        <p>${map.description}</p>
                    `;
                    mapsContainer.appendChild(mapDiv);
                });
            }
        });
});
